

function timeline() {
    // saveData[jatos.workerId] = dataToSave;
//   let updatedDates = updateDates();
//     if (updatedDates.fullDate.getDate() == updatedDates.yesterday.getDate()) { //|| yesterdayPlusOne.getDate() - fullDate.getDate() > 25 ) {
//             document.getElementById("fiveAM").style.display = "inline";
//         } 
//     else if (updatedDates.fullDate.getDate() == updatedDates.yesterdayPlusOne.getDate()) { //|| yesterdayPlusOne.getDate() - fullDate.getDate() > 25 ) {)
//         if (0 < updatedDates.fullDate.getHours() & updatedDates.fullDate.getHours() < 5) {
//             document.getElementById("fiveAM").style.display = "inline";
//         }else{
            document.getElementById("startButton").style.display = "inline";
            document.getElementById("redButton").style.display = "inline";
            document.getElementById("blueButton").style.display = "inline";
            document.getElementById("gameScreen").style.display = "inline";
            document.getElementById("startButton").onclick = function () {
            startClick = 1;
            if (startClick == 1) {
                document.getElementById("startButton").style.display = "none";
        let goInterval = async function () {  
        let doneInterval = await startInterval2Tests2 ();
        if (doneInterval == "done2") {
            let devTestST = async function () {
            let doneDayTwoST = await startDevTest(); // add promise and resolve
            if (doneDayTwoST == "doneDayFour") {
                jatos.studySessionData.doneDay2ST = "doneDayTwoST";
                showWinnings()
                jatos.studySessionData.expDaysDate = updatedDates.fullDate;
                // jatos.studySessionData(saveData);
                // jatos.submitResultData(saveData);
                setTimeout(() => {
                document.getElementById("endOfDayMessage").style.display = "none";
                document.getElementById("todayWins").innerHTML = '';
                document.getElementById("redWins").innerHTML = '';
                document.getElementById("blueWins").innerHTML = '';
                document.getElementById("seeYouTomorrow").innerHTML = '';
                document.getElementById("endOfGame").style.display = "inline";
                setTimeout(() => {
                    jatos.endStudyAjax(true, "great success");
                        }, 2000);
                    }, 5000);
                }
            } 
            devTestST
        }
        }
            
goInterval()
        }   
            }}              
// }else{
// document.getElementById("endOfGame").style.display = "inline";
// }    





// }