

// move to main function
function timeline() {
    // saveData[jatos.workerId] = dataToSave;
    let updatedDates = updateDates();
    let goSTone = async function () {
    let doneDayOne = await start2tests(); // add promise and resolve
        if (doneDayOne == "doneDayOne") {
                jatos.studySessionData.STdoneDay1 = "doneDayOne";
                showWinnings()
                jatos.studySessionData.expDaysDate = updatedDates.fullDate;
                // jatos.studySessionData(saveData);
                // jatos.submitResultData(saveData);
                setTimeout(() => {
                jatos.startComponentByPos(7);
                }, 3000)
                        //setTimeout(timeline(), 900000);
                    }
                }
            goSTone()
            }  
}
}                                   